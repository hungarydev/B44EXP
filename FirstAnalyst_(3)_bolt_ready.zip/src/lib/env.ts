export const ENV = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  GOLDAPI_KEY: process.env.GOLDAPI_KEY ?? "",
  COINGECKO_KEY: process.env.COINGECKO_KEY ?? "",
  FINMODPREP_KEY: process.env.FINMODPREP_KEY ?? "",
  SHOW_PLATINUM: (process.env.SHOW_PLATINUM ?? "true") === "true",
} as const;
