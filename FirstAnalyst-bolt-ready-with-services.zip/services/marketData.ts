type Source = "live" | "cached" | "mock";
export type Quote = { price: number; ts: number; source: Source };

// === INLINE CONFIG (replace values if needed) ===
const BASE_CCY = "USD";
const COINGECKO_KEY = "CG-958634suM9sAGmqguS1CVfVt";     // your CoinGecko key
const GOLDAPI_KEY   = "goldapi-yu5csmflvkmt9-io";         // your GoldAPI key
const USE_GOLDAPI   = true;                                // metals provider flag

// === CACHE & RATE LIMIT ===
const TTL_MS = 60_000;             // 60s cache
const MAX_CALLS_PER_MIN = 5;       // simple throttle
const CACHE: Record<string, Quote> = {};
let windowStart = Date.now();
let callCount = 0;
const now = () => Date.now();
function resetWindowIfNeeded(){ if(now()-windowStart >= 60_000){ windowStart = now(); callCount = 0; } }
function withinLimit(){ resetWindowIfNeeded(); if(callCount >= MAX_CALLS_PER_MIN) return false; callCount++; return true; }
function getCached(k:string){ const q = CACHE[k]; if(!q) return null; return (now()-q.ts <= TTL_MS) ? ({...q, source:"cached" as Source}) : null; }
function setCache(k:string, price:number, source:Source="live"){ const q:Quote = {price, ts:now(), source}; CACHE[k]=q; return q; }

// === SYMBOL MAP & POINT VALUES ===
function mapSymbolToCode(symbol:string): "BTC"|"XAU"|"XAG"|"XPT"|"XCU"|null{
  const s = symbol.toUpperCase();
  if(s==="BTG26") return "BTC"; if(s==="GCG26") return "XAU"; if(s==="SIG26") return "XAG";
  if(s==="PLJ26") return "XPT"; if(s==="HGG26") return "XCU"; return null;
}
export function getPointValue(symbol:string): number {
  const s = symbol.toUpperCase();
  if(s==="GCG26") return 100;
  if(s==="SIG26") return 5000;
  if(s==="HGG26") return 25000;
  if(s==="PLJ26") return 50;
  if(s==="BTG26") return 25;
  return 0;
}

// === SAFE FETCH ===
async function safeFetch(url:string, opts:RequestInit={}): Promise<Response|null>{
  if(!withinLimit()) return null;
  try { return await fetch(url, opts); } catch { return null; }
}

// === COINGECKO (BTC) ===
async function getBTCPriceUSD(): Promise<Quote>{
  const key = `BTC_${BASE_CCY}`;
  const cached = getCached(key);
  const url = "https://pro-api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd";
  const headers:Record<string,string> = {};
  if(COINGECKO_KEY) headers["x-cg-pro-api-key"] = COINGECKO_KEY;

  const res = await safeFetch(url, { headers });
  if(res && res.ok){
    const j:any = await res.json();
    const price = Number(j?.bitcoin?.usd ?? 0);
    if(price>0) return setCache(key, price, "live");
  }
  if(cached) return cached;
  return { price: 0, ts: now(), source:"mock" };
}

// === GOLDAPI (XAU/XAG/XPT/XCU) ===
async function getGoldAPIPrice(code:"XAU"|"XAG"|"XPT"|"XCU"): Promise<Quote>{
  const key = `${code}_${BASE_CCY}`;
  const cached = getCached(key);
  if(!USE_GOLDAPI || !GOLDAPI_KEY){
    return cached ?? { price:0, ts:now(), source:"mock" };
  }
  const url = `https://www.goldapi.io/api/${code}/USD`;
  const headers:Record<string,string> = { "Content-Type":"application/json", "x-access-token": GOLDAPI_KEY };

  const res = await safeFetch(url, { headers });
  if(res && res.ok){
    const j:any = await res.json();
    const price = Number(j?.price ?? j?.price_gram_24k ?? 0);
    if(price>0) return setCache(key, price, "live");
  }
  if(cached) return cached;
  return { price: 0, ts: now(), source:"mock" };
}

// === PUBLIC API ===
export async function getQuote(symbol:string): Promise<Quote>{
  const code = mapSymbolToCode(symbol);
  if(!code) return { price:0, ts:now(), source:"mock" };
  if(code==="BTC") return await getBTCPriceUSD();
  // Metals (XAU/XAG/XPT/XCU)
  return await getGoldAPIPrice(code as any);
}
export async function getQuotes(symbols:string[]): Promise<Record<string,Quote>>{
  const out:Record<string,Quote> = {};
  await Promise.all(symbols.map(async s => { out[s] = await getQuote(s); }));
  return out;
}
