import React from "react";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{minHeight:"100vh", background:"#0B0F14", color:"#E6EDF3"}}>
      <header style={{padding:"16px 24px", borderBottom:"1px solid #1E2A3A"}}>
        <strong>First Analysts Pro</strong>
      </header>
      <main style={{padding:"24px"}}>{children}</main>
    </div>
  );
}
